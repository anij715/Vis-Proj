//main bar chart
let data;
const parseTime = d3.timeParse("%Y-%m");

const dispatcher1 = d3.dispatch('filterCategories');
const dispatcher2 = d3.dispatch('filterCategories');
const dispatcher3 = d3.dispatch('filterCategories');

d3.csv('data/occurrences2.csv')
    .then(_data => {
        _data.forEach(d => {
            d.monthYear = d.year + "-" + d.month;
            // d.decimalLatitude = +d.decimalLatitude;
            // d.decimalLongitude = +d.decimalLongitude;
            d.latitude = +d.decimalLatitude; //make sure these are not strings
            d.longitude = +d.decimalLongitude;

            if (d.year == "null") {
                d.year = null;
            } else {
                d.year = +d.year;
            }
        });
        data = _data;


        //set the dimensions and margins of the graph
        var margin = { top: 20, right: 20, bottom: 110, left: 50 },
            width = 960 - margin.left - margin.right,
            height = 500 - margin.top - margin.bottom;

        // set the dimensions and margins of the graph
        var margin2 = { top: 430, right: 20, bottom: 30, left: 50 },
            width2 = 960 - margin.left - margin.right,
            height2 = 500 - margin.top - margin.bottom;


        /////////////////////// PLACE HOLDERS /////////////////////////////
        //VIS 1 START
        let monthLengthPerYear = d3.rollup(data, v => v.length, d => d.year, d => d.month)
        let dataNew = [];
        for (let [key, value] of monthLengthPerYear) {
            for (let [k, v] of value) {
                dataNew.push({
                    year: key,
                    month: k,
                    yearMonth: key + "-" + k,
                    lengthMonth: v
                })
            }
        }

        let sortYearMonth =
            dataNew.slice()
            .sort((a, b) => d3.ascending(a.yearMonth, b.yearMonth))

        sortYearMonth.forEach(function(d) {
            d.yearMonth = parseTime(d.yearMonth);
        });



        var svg = d3.select("#vis1")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform",
                "translate(" + margin.left + "," + margin.top + ")");

        const tooltip = d3.select("#vis1")
            .append("div")
            .style("opacity", 0)
            .attr("class", "tooltip")
            .style("background-color", "white")
            .style("border", "solid")
            .style("border-width", "1px")
            .style("border-radius", "5px")
            .style("padding", "10px")

        var x = d3.scaleTime().range([0, width]),
            x2 = d3.scaleTime().range([0, width]),
            y = d3.scaleLinear().range([height, 0]),
            y2 = d3.scaleLinear().range([height2, 0]);

        var xAxis = d3.axisBottom(x),
            xAxis2 = d3.axisBottom(x2),
            yAxis = d3.axisLeft(y);


        var area = d3.area()
            .curve(d3.curveMonotoneX)
            .x(function(d) { return x(d.yearMonth); })
            .y0(height)
            .y1(function(d) { return y(d.lengthMonth); });

        var area2 = d3.area()
            .curve(d3.curveMonotoneX)
            .x(function(d) { return x2(d.yearMonth); })
            .y0(height2)
            .y1(function(d) { return y2(d.lengthMonth); });

        svg.append("text")
            .attr("text-anchor", "end")
            .attr("x", (width / 2))
            .attr("y", height + margin.top + 40)
            .text("Months")

        svg.append("text")
            .attr("text-anchor", "end")
            .attr("transform", "rotate(-90)")
            .attr("y", -margin.left + 20)
            .attr("x", -margin.top)
            .text("Count of Specimens")

        svg.append("defs").append("clipPath")
            .attr("id", "clip")
            .append("rect")
            .attr("width", width)
            .attr("height", height);

        var focus = svg.append("g")
            .attr("class", "focus")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

        var context = svg.append("g")
            .attr("class", "context")
            .attr("transform", "translate(" + margin2.left + "," + margin2.top + ")");

        x.domain(d3.extent(sortYearMonth, function(d) { return d.yearMonth; }));
        y.domain([0, d3.max(sortYearMonth, function(d) { return d.lengthMonth; })]);
        x2.domain(x.domain());
        y2.domain(y.domain());

        focus.selectAll(".bar")
            .data(sortYearMonth)
            .enter().append("rect")
            .attr("class", "bar")
            .attr("x", function(d) { return x(d.yearMonth); })
            .attr("y", function(d) { return y(d.lengthMonth); })
            .attr("width", width / sortYearMonth.length)
            .attr("height", function(d) { return height - y(d.lengthMonth); })
            .attr("fill", "#56449B")
            .on('click', function(event, d) {
                console.log("Bar Clicked");
                // Check if current category is active and toggle class
                const isActive = d3.select(this).classed('active');
                d3.select(this).classed('active', !isActive);
                // Get the names of all active/filtered categories
                const selectedCategories = svg.selectAll('.bar.active').data().map(k => k.month);
                const categoryData = svg.selectAll('.bar.active').data()
                console.log("Selected Categories", categoryData);
                // Trigger filter event and pass array with the selected category names
                dispatcher1.call('filterCategories', event, selectedCategories);      
            });

        focus.append("g")
            .attr("class", "axis axis--x")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxis);

        focus.append("g")
            .attr("class", "axis axis--y")
            .call(yAxis);

        // context.append("path")
        //     .datum(sortYearMonth)
        //     .attr("class", "area")
        //     .attr("d", area2);

        // context.append("g")
        //     .attr("class", "axis axis--x")
        //     .attr("transform", "translate(0," + height2 + ")")
        //     .call(xAxis2);

        //VIS 1 END

        //VIS 2 START
        let lengthClasses = d3.rollup(data, v => v.length, d => d.class)
        A = lengthClasses.keys();
        B = lengthClasses.values();
        let dataNew2 = [];
        for (let [key, value] of lengthClasses) {
            dataNew2.push({
                name: key,
                lengthName: value
            })
        }


        const svg2 = d3.select("#vis2")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            //.attr("transform", `translate(${margin.left},${margin.top})`);
            .attr("transform",
                "translate(" + margin.left + "," + margin.top + ")");


        // X axis
        var x = d3.scaleBand()
            .range([0, width])
            .domain(dataNew2.map(d => d.name))
            .padding(0.2);
        svg2.append("g")
            .attr("transform", `translate(0, ${height})`)
            .call(d3.axisBottom(x))
            .selectAll("text")
            .attr("transform", "translate(-10,0)rotate(-45)")
            .attr("font-size","11")
            .style("text-anchor", "end");

        // Add Y axis
        var y = d3.scaleLinear()
            .domain([0, 5000])
            .range([height, 0]);
        svg2.append("g")
            .call(d3.axisLeft(y));

        svg2.append("text")
            .attr("text-anchor", "end")
            .attr("x", (width / 2))
            .attr("y", height + margin.top + 60)
            .text("Classes")

        svg2.append("text")
            .attr("text-anchor", "end")
            .attr("transform", "rotate(-90)")
            .attr("y", -margin.left + 10) // to move y axis label
            .attr("x", -margin.top)
            .text("Count of Classes")

        // Bars
        svg2.selectAll("mybar")
            .data(dataNew2)
            .join("rect")
            .attr("x", d => x(d.name))
            .attr("y", d => y(d.lengthName))
            .attr("width", x.bandwidth())
            .attr("height", d => height - y(d.lengthName))
            .attr("fill", "#56449B")
            .on('click', function(event, d) {
                console.log("Bar Clicked");
                // Check if current category is active and toggle class
                const isActive = d3.select(this).classed('active');
                d3.select(this).classed('active', !isActive);
                // Get the names of all active/filtered categories
                const selectedCategories = svg2.selectAll('.bar.active').data().map(k => k.name);
                const categoryData = svg2.selectAll('.bar.active').data()
                console.log("Selected Categories", categoryData);
                // Trigger filter event and pass array with the selected category names
                dispatcher2.call('filterCategories', event, selectedCategories);
      
                });

        // VIS 2 END

        // VIS 3 START
        let lengthRecordedBy = d3.rollup(data, v => v.length, d => d['recordedBy'])
        A = lengthRecordedBy.keys();
        B = lengthRecordedBy.values();

        let dataNew3 = [];
        for (let [key, value] of lengthRecordedBy) {
            dataNew3.push({
                name: key,
                lengthName: value
            })
        }

        // //Get the top 5 maximum lengths

        let topCollectors =
            dataNew3.slice().sort((a, b) => d3.descending(a.lengthName, b.lengthName))

        let topCollectors5 = topCollectors.splice(0, 5)
            // append the svg object to the body of the page
        const svg3 = d3.select("#vis3")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        // X axis
        var x = d3.scaleBand()
            .range([0, width])
            .domain(topCollectors5.map(d => d.name))
            .padding(0.2);
        svg3.append("g")
            .attr("transform", `translate(0, ${height})`)
            .call(d3.axisBottom(x))
            .selectAll("text")
            .attr("transform", "translate(-10,0)rotate(-45)")
            .attr("font-size","10")
            .style("text-anchor", "end");

        // Add Y axis
        var y = d3.scaleLinear()
            .domain([0, 5000])
            .range([height, 0]);
        svg3.append("g")
            .call(d3.axisLeft(y));

        svg3.append("text")
            .attr("text-anchor", "end")
            .attr("x", (width / 2))
            .attr("y", height + margin.top + 60)
            .text("Collectors")
            

        svg3.append("text")
            .attr("text-anchor", "end")
            .attr("transform", "rotate(-90)")
            .attr("y", -margin.left + 10)
            .attr("x", -margin.top)
            .text("Count of Collectors")
            


        // Bars
        svg3.selectAll("mybar")
            .data(topCollectors5)
            .join("rect")
            .attr("x", d => x(d.name))
            .attr("y", d => y(d.lengthName))
            .attr("width", x.bandwidth())
            .attr("height", d => height - y(d.lengthName))
            .attr("fill", "#56449B")
            .on('click', function(event, d) {
                console.log("Bar Clicked");
                // Check if current category is active and toggle class
                const isActive = d3.select(this).classed('active');
                d3.select(this).classed('active', !isActive);
                // Get the names of all active/filtered categories
                const selectedCategories = svg3.selectAll('.bar.active').data().map(k => k.name);
                const categoryData = svg3.selectAll('.bar.active').data()
                console.log("Selected Categories", categoryData);
                // Trigger filter event and pass array with the selected category names
                dispatcher3.call('filterCategories', event, selectedCategories);      
            }); 


        //VIS 3 END

        //VIS 4 START
        //Filter the data

        
        let latitudeData = data.filter(d => d.decimalLatitude != '9999999');

        // let longitudeData = data.filter( d => d.decimalLongitude != '9999999');


        let noLatitudeData = data.filter(d => d.decimalLatitude == '9999999');

        // let noLongitudeData = data.filter( d => d.decimalLongitude == '9999999');

        //Count the lengths of the filters
        let length1 = latitudeData.length
            // let length2 = longitudeData.length
        let length3 = noLatitudeData.length
            // let length4 = noLongitudeData.length

        // //Create New Data Object
        let nameObj = [{
                "name": "With Coordinate",
                "lengthName": length1
            },
            {
                "name": "Without Coordinates",
                "lengthName": length3
            }
        ];


        // append the svg object to the body of the page
        const svg4 = d3.select("#vis4")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        // X axis
        var x = d3.scaleBand()
            .range([0, width])
            .domain(nameObj.map(d => d.name))
            .padding(0.2);
        svg4.append("g")
            .attr("transform", `translate(0, ${height})`)
            .call(d3.axisBottom(x))
            .selectAll("text")
            .attr("transform", "translate(-10,0)rotate(-45)")
            .attr("font-size","12")
            .style("text-anchor", "end");

        // Add Y axis
        var y = d3.scaleLinear()
            .domain([0, 8000])
            .range([height, 0]);
        svg4.append("g")
            .call(d3.axisLeft(y));

        svg4.append("text")
            .attr("text-anchor", "end")
            .attr("transform", "rotate(-90)")
            .attr("y", -margin.left + 10)
            .attr("x", -margin.top)
            .text("Count")

        // Bars
        svg4.selectAll("mybar")
            .data(nameObj)
            .join("rect")
            .attr("x", d => x(d.name))
            .attr("y", d => y(d.lengthName))
            .attr("width", x.bandwidth())
            .attr("height", d => height - y(d.lengthName))
            .attr("fill", "#56449B");

        //VIS 4 END

        //VIS 5 START

        let eventVerbatimData = data.filter(d => d.day != 0);
        let noEventVerbatimData = data.filter(d => d.day == 0);
        //Count the lengths of the filters
        let lengthEvent = eventVerbatimData.length
        let lengthNoEvent = noEventVerbatimData.length


        // //Create New Data Object

        let nameEventObj = [{
                "name": "With Event Date",
                "lengthName": lengthEvent
            },
            {
                "name": "Without Event Date",
                "lengthName": lengthNoEvent
            }
        ];

        // append the svg object to the body of the page
        const svg5 = d3.select("#vis5")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        // X axis
        var x = d3.scaleBand()
            .range([0, width])
            .domain(nameEventObj.map(d => d.name))
            .padding(0.2);
        svg5.append("g")
            .attr("transform", `translate(0, ${height})`)
            .call(d3.axisBottom(x))
            .selectAll("text")
            .attr("transform", "translate(-10,0)rotate(-45)")
            .attr("font-size","12")
            .style("text-anchor", "end");

        // Add Y axis
        var y = d3.scaleLinear()
            .domain([0, 8000])
            .range([height, 0]);
        svg5.append("g")
            .call(d3.axisLeft(y));

        svg5.append("text")
            .attr("text-anchor", "end")
            .attr("transform", "rotate(-90)")
            .attr("y", -margin.left + 10)
            .attr("x", -margin.top)
            .text("Count")

        // Bars
        svg5.selectAll("mybar")
            .data(nameEventObj)
            .join("rect")
            .attr("x", d => x(d.name))
            .attr("y", d => y(d.lengthName))
            .attr("width", x.bandwidth())
            .attr("height", d => height - y(d.lengthName))
            .attr("fill", "#56449B");

        //VIS 5 END

        //////////////////////////////////////////////////////////////////

        //VIS 1 START
        d3.select('#start-year-input1').on('change', function() {
            console.log(1);
            d3.selectAll("svg > *").remove();

            const sYear = parseInt(d3.select("#start-year-input1").property('value'));
            const eYear = parseInt(d3.select("#end-year-input1").property('value'));
            let data1 = data.filter(function(d) { return d.year >= sYear && d.year <= eYear });


            //VIS 1 START
            let monthLengthPerYear = d3.rollup(data1, v => v.length, d => d.year, d => d.month)
            let dataNew = [];
            for (let [key, value] of monthLengthPerYear) {
                for (let [k, v] of value) {
                    dataNew.push({
                        year: key,
                        month: k,
                        yearMonth: key + "-" + k,
                        lengthMonth: v
                    })
                }
            }

            let sortYearMonth =
                dataNew.slice()
                .sort((a, b) => d3.ascending(a.yearMonth, b.yearMonth))

            sortYearMonth.forEach(function(d) {
                d.yearMonth = parseTime(d.yearMonth);
            });



            var svg = d3.select("#vis1")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                .attr("transform",
                    "translate(" + margin.left + "," + margin.top + ")");



            var x = d3.scaleTime().range([0, width]),
                x2 = d3.scaleTime().range([0, width]),
                y = d3.scaleLinear().range([height, 0]),
                y2 = d3.scaleLinear().range([height2, 0]);

            var xAxis = d3.axisBottom(x),
                xAxis2 = d3.axisBottom(x2),
                yAxis = d3.axisLeft(y);



            var area = d3.area()
                .curve(d3.curveMonotoneX)
                .x(function(d) { return x(d.yearMonth); })
                .y0(height)
                .y1(function(d) { return y(d.lengthMonth); });

            var area2 = d3.area()
                .curve(d3.curveMonotoneX)
                .x(function(d) { return x2(d.yearMonth); })
                .y0(height2)
                .y1(function(d) { return y2(d.lengthMonth); });

            svg.append("text")
                .attr("text-anchor", "end")
                .attr("x", (width / 2))
                .attr("y", height + margin.top + 40)
                .text("Months")

            svg.append("text")
                .attr("text-anchor", "end")
                .attr("transform", "rotate(-90)")
                .attr("y", -margin.left + 20)
                .attr("x", -margin.top)
                .text("Count of Specimens")


            svg.append("defs").append("clipPath")
                .attr("id", "clip")
                .append("rect")
                .attr("width", width)
                .attr("height", height);

            var focus = svg.append("g")
                .attr("class", "focus")
                .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

            var context = svg.append("g")
                .attr("class", "context")
                .attr("transform", "translate(" + margin2.left + "," + margin2.top + ")");

            x.domain(d3.extent(sortYearMonth, function(d) { return d.yearMonth; }));
            y.domain([0, d3.max(sortYearMonth, function(d) { return d.lengthMonth; })]);
            x2.domain(x.domain());
            y2.domain(y.domain());

            focus.selectAll(".bar")
                .data(sortYearMonth)
                .enter().append("rect")
                .attr("class", "bar")
                .attr("x", function(d) { return x(d.yearMonth); })
                .attr("y", function(d) { return y(d.lengthMonth); })
                .attr("width", width / sortYearMonth.length)
                .attr("height", function(d) { return height - y(d.lengthMonth); })
                .attr("fill", "#56449B")
                .on('click', function(event, d) {
                    console.log("Bar Clicked");
                    // Check if current category is active and toggle class
                    const isActive = d3.select(this).classed('active');
                    d3.select(this).classed('active', !isActive);
                    // Get the names of all active/filtered categories
                    const selectedCategories = svg.selectAll('.bar.active').data().map(k => k.month);
                    const categoryData = svg.selectAll('.bar.active').data()
                    console.log("Selected Categories", categoryData);
                    // Trigger filter event and pass array with the selected category names
                    dispatcher1.call('filterCategories', event, selectedCategories);      
                });

            focus.append("g")
                .attr("class", "axis axis--x")
                .attr("transform", "translate(0," + height + ")")
                .call(xAxis);

            focus.append("g")
                .attr("class", "axis axis--y")
                .call(yAxis);

            // context.append("path")
            //     .datum(sortYearMonth)
            //     .attr("class", "area")
            //     .attr("d", area2);

            // context.append("g")
            //     .attr("class", "axis axis--x")
            //     .attr("transform", "translate(0," + height2 + ")")
            //     .call(xAxis2);


            //VIS 1 END

            //VIS 2 START
            let lengthClasses = d3.rollup(data1, v => v.length, d => d.class)
            A = lengthClasses.keys();
            B = lengthClasses.values();
            let dataNew2 = [];
            for (let [key, value] of lengthClasses) {
                dataNew2.push({
                    name: key,
                    lengthName: value
                })
            }


            // append the svg object to the body of the page || //.append("svg1")
            var svg2 = d3.select("#vis2")
                //.append("svg")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                //.attr("transform", `translate(${margin.left},${margin.top})`);
                .attr("transform",
                    "translate(" + margin.left + "," + margin.top + ")");


            // X axis
            var x = d3.scaleBand()
                .range([0, width])
                .domain(dataNew2.map(d => d.name))
                .padding(0.2);
            svg2.append("g")
                .attr("transform", `translate(0, ${height})`)
                .call(d3.axisBottom(x))
                .selectAll("text")
                .attr("transform", "translate(-10,0)rotate(-45)")
                .style("text-anchor", "end");

            // Add Y axis
            var y = d3.scaleLinear()
                .domain([0, 5000])
                .range([height, 0]);
            svg2.append("g")
                .call(d3.axisLeft(y));

            svg2.append("text")
                .attr("text-anchor", "end")
                .attr("x", (width / 2))
                .attr("y", height + margin.top + 60)
                .text("Classes")

            svg2.append("text")
                .attr("text-anchor", "end")
                .attr("transform", "rotate(-90)")
                .attr("y", -margin.left + 10)
                .attr("x", -margin.top)
                .text("Count of Classes")

            // Bars
            svg2.selectAll("mybar")
                .data(dataNew2)
                .join("rect")
                .attr("x", d => x(d.name))
                .attr("y", d => y(d.lengthName))
                .attr("width", x.bandwidth())
                .attr("height", d => height - y(d.lengthName))
                .attr("fill", "#56449B")
                .on('click', function(event, d) {
                    console.log("Bar Clicked");
                    // Check if current category is active and toggle class
                    const isActive = d3.select(this).classed('active');
                    d3.select(this).classed('active', !isActive);
                    // Get the names of all active/filtered categories
                    const selectedCategories = svg2.selectAll('.bar.active').data().map(k => k.name);
                    const categoryData = svg2.selectAll('.bar.active').data()
                    console.log("Selected Categories", categoryData);
                    // Trigger filter event and pass array with the selected category names
                    dispatcher2.call('filterCategories', event, selectedCategories);          
                });

            //VIS 2 END

            // VIS 3 START
            let lengthRecordedBy = d3.rollup(data1, v => v.length, d => d['recordedBy'])
            A = lengthRecordedBy.keys();
            B = lengthRecordedBy.values();

            let dataNew3 = [];
            for (let [key, value] of lengthRecordedBy) {
                dataNew3.push({
                    name: key,
                    lengthName: value
                })
            }

            // //Get the top 5 maximum lengths

            let topCollectors =
                dataNew3.slice().sort((a, b) => d3.descending(a.lengthName, b.lengthName))

            let topCollectors5 = topCollectors.splice(0, 5)
                // append the svg object to the body of the page
            const svg3 = d3.select("#vis3")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                .attr("transform", `translate(${margin.left},${margin.top})`);

            // X axis
            var x = d3.scaleBand()
                .range([0, width])
                .domain(topCollectors5.map(d => d.name))
                .padding(0.2);
            svg3.append("g")
                .attr("transform", `translate(0, ${height})`)
                .call(d3.axisBottom(x))
                .selectAll("text")
                .attr("transform", "translate(-10,0)rotate(-45)")
                .style("text-anchor", "end");

            // Add Y axis
            var y = d3.scaleLinear()
                .domain([0, 5000])
                .range([height, 0]);
            svg3.append("g")
                .call(d3.axisLeft(y));

            svg3.append("text")
                .attr("text-anchor", "end")
                .attr("x", (width / 2))
                .attr("y", height + margin.top + 60)
                .text("Collectors")
            svg3.append("text")
                .attr("text-anchor", "end")
                .attr("transform", "rotate(-90)")
                .attr("y", -margin.left + 10)
                .attr("x", -margin.top)
                .text("Count of Collectors")


            // Bars
            svg3.selectAll("mybar")
                .data(topCollectors5)
                .join("rect")
                .attr("x", d => x(d.name))
                .attr("y", d => y(d.lengthName))
                .attr("width", x.bandwidth())
                .attr("height", d => height - y(d.lengthName))
                .attr("fill", "#56449B")
                .on('click', function(event, d) {
                    console.log("Bar Clicked");
                    // Check if current category is active and toggle class
                    const isActive = d3.select(this).classed('active');
                    d3.select(this).classed('active', !isActive);
                    // Get the names of all active/filtered categories
                    const selectedCategories = svg3.selectAll('.bar.active').data().map(k => k.name);
                    const categoryData = svg3.selectAll('.bar.active').data()
                    console.log("Selected Categories", categoryData);
                    // Trigger filter event and pass array with the selected category names
                    dispatcher3.call('filterCategories', event, selectedCategories);      
                }); 

            //VIS 3 END


            //VIS 4 START
            //Filter the data
            let latitudeData = data1.filter(d => d.decimalLatitude != '9999999');
            // let longitudeData = data.filter( d => d.decimalLongitude != '9999999');
            let noLatitudeData = data1.filter(d => d.decimalLatitude == '9999999');
            // let noLongitudeData = data.filter( d => d.decimalLongitude == '9999999');

            //Count the lengths of the filters
            let length1 = latitudeData.length
                // let length2 = longitudeData.length
            let length3 = noLatitudeData.length
                // let length4 = noLongitudeData.length

            // //Create New Data Object
            let nameObj = [{
                    "name": "With Coordinate",
                    "lengthName": length1
                },
                {
                    "name": "Without Coordinates",
                    "lengthName": length3
                }
            ];


            // append the svg object to the body of the page
            const svg4 = d3.select("#vis4")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                .attr("transform", `translate(${margin.left},${margin.top})`);

            // X axis
            var x = d3.scaleBand()
                .range([0, width])
                .domain(nameObj.map(d => d.name))
                .padding(0.2);
            svg4.append("g")
                .attr("transform", `translate(0, ${height})`)
                .call(d3.axisBottom(x))
                .selectAll("text")
                .attr("transform", "translate(-10,0)rotate(-45)")
                .style("text-anchor", "end");

            // Add Y axis
            var y = d3.scaleLinear()
                .domain([0, 8000])
                .range([height, 0]);
            svg4.append("g")
                .call(d3.axisLeft(y));

            svg4.append("text")
                .attr("text-anchor", "end")
                .attr("transform", "rotate(-90)")
                .attr("y", -margin.left + 10)
                .attr("x", -margin.top)
                .text("Count")

            // Bars
            svg4.selectAll("mybar")
                .data(nameObj)
                .join("rect")
                .attr("x", d => x(d.name))
                .attr("y", d => y(d.lengthName))
                .attr("width", x.bandwidth())
                .attr("height", d => height - y(d.lengthName))
                .attr("fill", "#56449B");

            //VIS 4 END

            //VIS 5 START

            let eventVerbatimData = data1.filter(d => d.day != 0);
            let noEventVerbatimData = data1.filter(d => d.day == 0);
            //Count the lengths of the filters
            let lengthEvent = eventVerbatimData.length
            let lengthNoEvent = noEventVerbatimData.length


            // //Create New Data Object

            let nameEventObj = [{
                    "name": "With Event Date",
                    "lengthName": lengthEvent
                },
                {
                    "name": "Without Event Date",
                    "lengthName": lengthNoEvent
                }
            ];

            // append the svg object to the body of the page
            const svg5 = d3.select("#vis5")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                .attr("transform", `translate(${margin.left},${margin.top})`);

            // X axis
            var x = d3.scaleBand()
                .range([0, width])
                .domain(nameEventObj.map(d => d.name))
                .padding(0.2);
            svg5.append("g")
                .attr("transform", `translate(0, ${height})`)
                .call(d3.axisBottom(x))
                .selectAll("text")
                .attr("transform", "translate(-10,0)rotate(-45)")
                .style("text-anchor", "end");

            // Add Y axis
            var y = d3.scaleLinear()
                .domain([0, 8000])
                .range([height, 0]);
            svg5.append("g")
                .call(d3.axisLeft(y));

            svg5.append("text")
                .attr("text-anchor", "end")
                .attr("transform", "rotate(-90)")
                .attr("y", -margin.left + 10)
                .attr("x", -margin.top)
                .text("Count")

            // Bars
            svg5.selectAll("mybar")
                .data(nameEventObj)
                .join("rect")
                .attr("x", d => x(d.name))
                .attr("y", d => y(d.lengthName))
                .attr("width", x.bandwidth())
                .attr("height", d => height - y(d.lengthName))
                .attr("fill", "#56449B");

            //VIS 5 END

        });

        d3.select('#end-year-input1').on('change', function() {
            console.log(2);
            d3.selectAll("svg > *").remove();

            const sYear = parseInt(d3.select("#start-year-input1").property('value'));
            const eYear = parseInt(d3.select("#end-year-input1").property('value'));
            let data1 = data.filter(function(d) { return d.year >= sYear && d.year <= eYear });


            //VIS 1 START
            let monthLengthPerYear = d3.rollup(data1, v => v.length, d => d.year, d => d.month)
            let dataNew = [];
            for (let [key, value] of monthLengthPerYear) {
                for (let [k, v] of value) {
                    dataNew.push({
                        year: key,
                        month: k,
                        yearMonth: key + "-" + k,
                        lengthMonth: v
                    })
                }
            }

            let sortYearMonth =
                dataNew.slice()
                .sort((a, b) => d3.ascending(a.yearMonth, b.yearMonth))

            sortYearMonth.forEach(function(d) {
                d.yearMonth = parseTime(d.yearMonth);
            });



            var svg = d3.select("#vis1")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                .attr("transform",
                    "translate(" + margin.left + "," + margin.top + ")");



            var x = d3.scaleTime().range([0, width]),
                x2 = d3.scaleTime().range([0, width]),
                y = d3.scaleLinear().range([height, 0]),
                y2 = d3.scaleLinear().range([height2, 0]);

            var xAxis = d3.axisBottom(x),
                xAxis2 = d3.axisBottom(x2),
                yAxis = d3.axisLeft(y);



            var area = d3.area()
                .curve(d3.curveMonotoneX)
                .x(function(d) { return x(d.yearMonth); })
                .y0(height)
                .y1(function(d) { return y(d.lengthMonth); });

            var area2 = d3.area()
                .curve(d3.curveMonotoneX)
                .x(function(d) { return x2(d.yearMonth); })
                .y0(height2)
                .y1(function(d) { return y2(d.lengthMonth); });

            svg.append("text")
                .attr("text-anchor", "end")
                .attr("x", (width / 2))
                .attr("y", height + margin.top + 40)
                .text("Months")

            svg.append("text")
                .attr("text-anchor", "end")
                .attr("transform", "rotate(-90)")
                .attr("y", -margin.left + 20)
                .attr("x", -margin.top)
                .text("Count of Specimens")

            svg.append("defs").append("clipPath")
                .attr("id", "clip")
                .append("rect")
                .attr("width", width)
                .attr("height", height);

            var focus = svg.append("g")
                .attr("class", "focus")
                .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

            var context = svg.append("g")
                .attr("class", "context")
                .attr("transform", "translate(" + margin2.left + "," + margin2.top + ")");

            x.domain(d3.extent(sortYearMonth, function(d) { return d.yearMonth; }));
            y.domain([0, d3.max(sortYearMonth, function(d) { return d.lengthMonth; })]);
            x2.domain(x.domain());
            y2.domain(y.domain());

            focus.selectAll(".bar")
                .data(sortYearMonth)
                .enter().append("rect")
                .attr("class", "bar")
                .attr("x", function(d) { return x(d.yearMonth); })
                .attr("y", function(d) { return y(d.lengthMonth); })
                .attr("width", width / sortYearMonth.length)
                .attr("height", function(d) { return height - y(d.lengthMonth); })
                .attr("fill", "#56449B")
                .on('click', function(event, d) {
                    console.log("Bar Clicked");
                    // Check if current category is active and toggle class
                    const isActive = d3.select(this).classed('active');
                    d3.select(this).classed('active', !isActive);
                    // Get the names of all active/filtered categories
                    const selectedCategories = svg.selectAll('.bar.active').data().map(k => k.month);
                    const categoryData = svg.selectAll('.bar.active').data()
                    console.log("Selected Categories", categoryData);
                    // Trigger filter event and pass array with the selected category names
                    dispatcher1.call('filterCategories', event, selectedCategories);      
                });

            focus.append("g")
                .attr("class", "axis axis--x")
                .attr("transform", "translate(0," + height + ")")
                .call(xAxis);

            focus.append("g")
                .attr("class", "axis axis--y")
                .call(yAxis);

            // context.append("path")
            //     .datum(sortYearMonth)
            //     .attr("class", "area")
            //     .attr("d", area2);

            // context.append("g")
            //     .attr("class", "axis axis--x")
            //     .attr("transform", "translate(0," + height2 + ")")
            //     .call(xAxis2);


            //VIS 1 END

            //VIS 2 START
            let lengthClasses = d3.rollup(data1, v => v.length, d => d.class)
            A = lengthClasses.keys();
            B = lengthClasses.values();
            let dataNew2 = [];
            for (let [key, value] of lengthClasses) {
                dataNew2.push({
                    name: key,
                    lengthName: value
                })
            }


            // append the svg object to the body of the page || //.append("svg1")
            var svg2 = d3.select("#vis2")
                //.append("svg")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                //.attr("transform", `translate(${margin.left},${margin.top})`);
                .attr("transform",
                    "translate(" + margin.left + "," + margin.top + ")");


            // X axis
            var x = d3.scaleBand()
                .range([0, width])
                .domain(dataNew2.map(d => d.name))
                .padding(0.2);
            svg2.append("g")
                .attr("transform", `translate(0, ${height})`)
                .call(d3.axisBottom(x))
                .selectAll("text")
                .attr("transform", "translate(-10,0)rotate(-45)")
                .style("text-anchor", "end");

            // Add Y axis
            var y = d3.scaleLinear()
                .domain([0, 5000])
                .range([height, 0]);
            svg2.append("g")
                .call(d3.axisLeft(y));

            svg2.append("text")
                .attr("text-anchor", "end")
                .attr("x", (width / 2))
                .attr("y", height + margin.top + 60)
                .text("Classes")
            svg2.append("text")
                .attr("text-anchor", "end")
                .attr("transform", "rotate(-90)")
                .attr("y", -margin.left + 10)
                .attr("x", -margin.top)
                .text("Count of Classes")

            // Bars
            svg2.selectAll("mybar")
                .data(dataNew2)
                .join("rect")
                .attr("x", d => x(d.name))
                .attr("y", d => y(d.lengthName))
                .attr("width", x.bandwidth())
                .attr("height", d => height - y(d.lengthName))
                .attr("fill", "#56449B")
                .on('click', function(event, d) {
                    console.log("Bar Clicked");
                    // Check if current category is active and toggle class
                    const isActive = d3.select(this).classed('active');
                    d3.select(this).classed('active', !isActive);
                    // Get the names of all active/filtered categories
                    const selectedCategories = svg2.selectAll('.bar.active').data().map(k => k.name);
                    const categoryData = svg2.selectAll('.bar.active').data()
                    console.log("Selected Categories", categoryData);
                    // Trigger filter event and pass array with the selected category names
                    dispatcher2.call('filterCategories', event, selectedCategories);
          
                });

            //VIS 2 END

            // VIS 3 START
            let lengthRecordedBy = d3.rollup(data1, v => v.length, d => d['recordedBy'])
            A = lengthRecordedBy.keys();
            B = lengthRecordedBy.values();

            let dataNew3 = [];
            for (let [key, value] of lengthRecordedBy) {
                dataNew3.push({
                    name: key,
                    lengthName: value
                })
            }

            // //Get the top 5 maximum lengths

            let topCollectors =
                dataNew3.slice().sort((a, b) => d3.descending(a.lengthName, b.lengthName))

            let topCollectors5 = topCollectors.splice(0, 5)
                // append the svg object to the body of the page
            const svg3 = d3.select("#vis3")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                .attr("transform", `translate(${margin.left},${margin.top})`);

            // X axis
            var x = d3.scaleBand()
                .range([0, width])
                .domain(topCollectors5.map(d => d.name))
                .padding(0.2);
            svg3.append("g")
                .attr("transform", `translate(0, ${height})`)
                .call(d3.axisBottom(x))
                .selectAll("text")
                .attr("transform", "translate(-10,0)rotate(-45)")
                .style("text-anchor", "end");

            svg3.append("text")
                .attr("text-anchor", "end")
                .attr("x", (width / 2))
                .attr("y", height + margin.top + 60)
                .text("Collectors")
            svg3.append("text")
                .attr("text-anchor", "end")
                .attr("transform", "rotate(-90)")
                .attr("y", -margin.left + 10)
                .attr("x", -margin.top)
                .text("Count of Collectors")

            // Add Y axis
            var y = d3.scaleLinear()
                .domain([0, 5000])
                .range([height, 0]);
            svg3.append("g")
                .call(d3.axisLeft(y));

            // Bars
            svg3.selectAll("mybar")
                .data(topCollectors5)
                .join("rect")
                .attr("x", d => x(d.name))
                .attr("y", d => y(d.lengthName))
                .attr("width", x.bandwidth())
                .attr("height", d => height - y(d.lengthName))
                .attr("fill", "#56449B")
                .on('click', function(event, d) {
                    console.log("Bar Clicked");
                    // Check if current category is active and toggle class
                    const isActive = d3.select(this).classed('active');
                    d3.select(this).classed('active', !isActive);
                    // Get the names of all active/filtered categories
                    const selectedCategories = svg3.selectAll('.bar.active').data().map(k => k.name);
                    const categoryData = svg3.selectAll('.bar.active').data()
                    console.log("Selected Categories", categoryData);
                    // Trigger filter event and pass array with the selected category names
                    dispatcher3.call('filterCategories', event, selectedCategories);      
                }); 


            //VIS 3 END


            //VIS 4 START
            //Filter the data
            let latitudeData = data1.filter(d => d.decimalLatitude != '9999999');
            // let longitudeData = data.filter( d => d.decimalLongitude != '9999999');
            let noLatitudeData = data1.filter(d => d.decimalLatitude == '9999999');
            // let noLongitudeData = data.filter( d => d.decimalLongitude == '9999999');

            //Count the lengths of the filters
            let length1 = latitudeData.length
                // let length2 = longitudeData.length
            let length3 = noLatitudeData.length
                // let length4 = noLongitudeData.length

            // //Create New Data Object
            let nameObj = [{
                    "name": "With Coordinate",
                    "lengthName": length1
                },
                {
                    "name": "Without Coordinates",
                    "lengthName": length3
                }
            ];


            // append the svg object to the body of the page
            const svg4 = d3.select("#vis4")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                .attr("transform", `translate(${margin.left},${margin.top})`);

            // X axis
            var x = d3.scaleBand()
                .range([0, width])
                .domain(nameObj.map(d => d.name))
                .padding(0.2);
            svg4.append("g")
                .attr("transform", `translate(0, ${height})`)
                .call(d3.axisBottom(x))
                .selectAll("text")
                .attr("transform", "translate(-10,0)rotate(-45)")
                .style("text-anchor", "end");

            // Add Y axis
            var y = d3.scaleLinear()
                .domain([0, 8000])
                .range([height, 0]);
            svg4.append("g")
                .call(d3.axisLeft(y));

            svg4.append("text")
                .attr("text-anchor", "end")
                .attr("transform", "rotate(-90)")
                .attr("y", -margin.left + 10)
                .attr("x", -margin.top)
                .text("Count")

            // Bars
            svg4.selectAll("mybar")
                .data(nameObj)
                .join("rect")
                .attr("x", d => x(d.name))
                .attr("y", d => y(d.lengthName))
                .attr("width", x.bandwidth())
                .attr("height", d => height - y(d.lengthName))
                .attr("fill", "#56449B");

            //VIS 4 END

            //VIS 5 START

            let eventVerbatimData = data1.filter(d => d.day != 0);
            let noEventVerbatimData = data1.filter(d => d.day == 0);
            //Count the lengths of the filters
            let lengthEvent = eventVerbatimData.length
            let lengthNoEvent = noEventVerbatimData.length


            // //Create New Data Object

            let nameEventObj = [{
                    "name": "With Event Date",
                    "lengthName": lengthEvent
                },
                {
                    "name": "Without Event Date",
                    "lengthName": lengthNoEvent
                }
            ];

            // append the svg object to the body of the page
            const svg5 = d3.select("#vis5")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                .attr("transform", `translate(${margin.left},${margin.top})`);

            // X axis
            var x = d3.scaleBand()
                .range([0, width])
                .domain(nameEventObj.map(d => d.name))
                .padding(0.2);
            svg5.append("g")
                .attr("transform", `translate(0, ${height})`)
                .call(d3.axisBottom(x))
                .selectAll("text")
                .attr("transform", "translate(-10,0)rotate(-45)")
                .style("text-anchor", "end");

            // Add Y axis
            var y = d3.scaleLinear()
                .domain([0, 8000])
                .range([height, 0]);
            svg5.append("g")
                .call(d3.axisLeft(y));

            svg5.append("text")
                .attr("text-anchor", "end")
                .attr("transform", "rotate(-90)")
                .attr("y", -margin.left + 10)
                .attr("x", -margin.top)
                .text("Count")

            // Bars
            svg5.selectAll("mybar")
                .data(nameEventObj)
                .join("rect")
                .attr("x", d => x(d.name))
                .attr("y", d => y(d.lengthName))
                .attr("width", x.bandwidth())
                .attr("height", d => height - y(d.lengthName))
                .attr("fill", "#56449B");

            //VIS 5 END
        });



    })
    .catch(error => console.error(error));

    dispatcher1.on('filterCategories', selectedCategories => {
        console.log("Data");
        
            if (selectedCategories.length == 0) {
                leafletMap.data = data;
            } else {
                leafletMap.data = data.filter(d => selectedCategories.includes(d.month));
            }
            leafletMap.updateVis();
    });


    dispatcher2.on('filterCategories', selectedCategories => {
    console.log("Data");
    
        if (selectedCategories.length == 0) {
            leafletMap.data = data;
        } else {
            leafletMap.data = data.filter(d => selectedCategories.includes(d.class));
        }
        leafletMap.updateVis();
        });

        dispatcher3.on('filterCategories', selectedCategories => {
            console.log("Data");
            
                if (selectedCategories.length == 0) {
                    leafletMap.data = data;
                } else {
                    leafletMap.data = data.filter(d => selectedCategories.includes(d['recordedBy']));
                }
                leafletMap.updateVis();
            });