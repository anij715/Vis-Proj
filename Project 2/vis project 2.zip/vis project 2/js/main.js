let data;
d3.csv('data/occurrences1.csv')
    .then(_data => {
        _data.forEach(d => {
            d.latitude = +d.decimalLatitude; //make sure these are not strings
            d.longitude = +d.decimalLongitude; //make sure these are not strings

            if (d.year == "null") {
                d.year = null;
            } else {
                d.year = +d.year;
            }

        });
        data = _data;
        let filteredData1 = data.filter(function(d) { return d.year >= 1859 && d.year <= 2017 });
        leafletMap = new LeafletMap({ parentElement: '#my-map' }, filteredData1);
        //console.log(3);
    })
    .catch(error => console.error(error));

d3.select('#display-type-selection').on('change', function() {
    const mapUrl = (d3.select("#display-type-selection").property('value'));
    //console.log(mapUrl);
    if (mapUrl == 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}') {
        //console.log("Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community");
        leafletMap.config.displayUrl = mapUrl;
        leafletMap.config.displayAttr = 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community';

    } else if (mapUrl == 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png') {
        //console.log("map2");
        leafletMap.config.displayUrl = mapUrl;
        leafletMap.config.displayAttr = 'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)';
    } else if (mapUrl == 'https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png') {
        //console.log("map3");
        leafletMap.config.displayUrl = mapUrl;
        leafletMap.config.displayAttr = '&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors';
    } else if (mapUrl == 'https://stamen-tiles-{s}.a.ssl.fastly.net/terrain/{z}/{x}/{y}{r}.{ext}') {
        //console.log("map4");
        leafletMap.config.displayUrl = mapUrl;
        leafletMap.config.displayAttr = 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';
    }

    const sYear = parseInt(d3.select("#start-year-input").property('value'));
    const eYear = parseInt(d3.select("#end-year-input").property('value'));
    let filteredData = data.filter(function(d) { return d.year >= sYear && d.year <= eYear });
    leafletMap.base_layer.remove();
    leafletMap.theMap.remove();
    leafletMap.config.displayType = d3.select(this).property('value');
    leafletMap.data = filteredData;
    leafletMap.initVis();
    leafletMap.updateVis();
});
d3.select('#start-year-input').on('change', function() {
    console.log(4);
    const sYear = parseInt(d3.select("#start-year-input").property('value'));
    const eYear = parseInt(d3.select("#end-year-input").property('value'));
    let filteredData = data.filter(function(d) { return d.year >= sYear && d.year <= eYear });
    //leafletMap1 = new LeafletMap({ parentElement: '#my-map' }, filteredData);
    leafletMap.config.displayType = d3.select(this).property('value');
    leafletMap.data = filteredData;
    leafletMap.updateVis();
});


d3.select('#end-year-input').on('change', function() {
    console.log(4);
    const sYear = parseInt(d3.select("#start-year-input").property('value'));
    const eYear = parseInt(d3.select("#end-year-input").property('value'));
    let filteredData = data.filter(function(d) { return d.year >= sYear && d.year <= eYear });
    leafletMap.config.displayType = d3.select(this).property('value');
    leafletMap.data = filteredData;
    leafletMap.updateVis();

});