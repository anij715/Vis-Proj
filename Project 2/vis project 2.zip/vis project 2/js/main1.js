const parseTime = d3.timeParse("%Y-%m-%d");
let data1, lineChart;

d3.csv('data/yearcount.csv')
    .then(_data1 => {
        _data1.forEach(d => {
            d.year = +d.year;
            d.count = +d.count;

        });

        data1 = _data1;
        lineChart = new LineChart({ parentElement: '#timeline' }, data1);
        lineChart.updateVis();

    })
    .catch(error => console.error(error));